package com.example.chatapp;

public class login {

    private user registeredUser = null;

    // Username validation
    public boolean checkUsername(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Password validation
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;

        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }

    // SA cellphone validation
    public boolean checkCellphone(String cellphone) {
        return cellphone != null && cellphone.matches("^\\+27\\d{9}$");
    }

    // Register user
    public String registerUser(String username, String password, String cellphone) {

        if (!checkUsername(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellphone(cellphone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        registeredUser = new user(username, password, cellphone);
        return "Registration successful.";
    }

    // Login check
    public boolean loginUser(String username, String password) {
        if (registeredUser == null) return false;

        return registeredUser.getUsername().equals(username)
                && registeredUser.getPassword().equals(password);
    }

    // Login message
    public String returnLoginStatus(boolean loginSuccess, String username) {

        if (!loginSuccess) {
            return "Username or password incorrect, please try again.";
        }

        String[] parts = username.split("_");
        String firstName = parts.length > 0 ? parts[0] : "";
        String lastName = parts.length > 1 ? parts[1] : "";

        return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
    }
}
