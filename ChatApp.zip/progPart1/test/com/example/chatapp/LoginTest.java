package com.example.chatapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    // ---------------- USERNAME TESTS ----------------

    @Test
    public void testUsernameCorrectlyFormatted() {
        login l = new login();
        assertTrue(l.checkUsername("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        login l = new login();
        assertFalse(l.checkUsername("kyle!!!!"));
    }

    // ---------------- PASSWORD TESTS ----------------

    @Test
    public void testPasswordMeetsComplexity() {
        login l = new login();
        assertTrue(l.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexity() {
        login l = new login();
        assertFalse(l.checkPasswordComplexity("password"));
    }

    // ---------------- CELLPHONE TESTS ----------------

    @Test
    public void testCellphoneCorrectlyFormatted() {
        login l = new login();
        assertTrue(l.checkCellphone("+27838968976"));
    }

    @Test
    public void testCellphoneIncorrectlyFormatted() {
        login l = new login();
        assertFalse(l.checkCellphone("08966553"));
    }

    // ---------------- REGISTRATION TESTS ----------------

    @Test
    public void testRegistrationSuccess() {
        login l = new login();
        String result = l.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        assertEquals("Registration successful.", result);
    }

    @Test
    public void testRegistrationFailsUsername() {
        login l = new login();
        String result = l.registerUser("kyle", "Ch&&sec@ke99!", "+27838968976");

        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    public void testRegistrationFailsPassword() {
        login l = new login();
        String result = l.registerUser("kyl_1", "password", "+27838968976");

        assertTrue(result.contains("Password is not correctly formatted"));
    }

    @Test
    public void testRegistrationFailsCellphone() {
        login l = new login();
        String result = l.registerUser("kyl_1", "Ch&&sec@ke99!", "083123");

        assertTrue(result.contains("Cell phone number incorrectly formatted"));
    }

    // ---------------- LOGIN TESTS ----------------

    @Test
    public void testLoginSuccess() {
        login l = new login();
        l.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        boolean loginStatus = l.loginUser("kyl_1", "Ch&&sec@ke99!");
        assertTrue(loginStatus);
    }

    @Test
    public void testLoginFailure() {
        login l = new login();
        l.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        boolean loginStatus = l.loginUser("kyl_1", "wrongpass");
        assertFalse(loginStatus);
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        login l = new login();
        String message = l.returnLoginStatus(true, "kyl_1");

        assertTrue(message.contains("Welcome"));
    }

    @Test
    public void testReturnLoginStatusFailure() {
        login l = new login();
        String message = l.returnLoginStatus(false, "kyl_1");

        assertEquals("Username or password incorrect, please try again.", message);
    }
}

