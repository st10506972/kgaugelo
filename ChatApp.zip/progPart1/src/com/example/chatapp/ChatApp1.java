package com.example.chatapp;

import java.util.Scanner;

public class ChatApp1 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        login loginSystem = new login();

        System.out.println("=== Welcome to Chat Application ===");

        // ---------------- REGISTER ----------------
        System.out.println("\n--- Registration ---");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter South African cellphone (+27...): ");
        String cellphone = input.nextLine();

        String registrationMessage = loginSystem.registerUser(username, password, cellphone);
        System.out.println(registrationMessage);

        // ---------------- LOGIN ----------------
        System.out.println("\n--- Login ---");

        System.out.print("Enter username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = input.nextLine();

        boolean loginSuccess = loginSystem.loginUser(loginUsername, loginPassword);

        String loginMessage = loginSystem.returnLoginStatus(loginSuccess, loginUsername);
        System.out.println(loginMessage);

        input.close();
    }
}



    
